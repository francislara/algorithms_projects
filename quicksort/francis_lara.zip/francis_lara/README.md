## Quicksort In-place

Refer to the videos for instructions on how to implement this method.

This project is shorter than most. It is **HIGHLY** recommended that you use your extra time to begin fixing your resumes, FSPs, and JS projects; applications start on Monday!!!
